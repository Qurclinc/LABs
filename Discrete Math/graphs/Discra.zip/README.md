## All codes are done by DeepSeek AI-Assistant. I had no time to understand this topic, but had to this labs be done.

Lab7 - Binary Operations
Lab8 - Wave Algorithm
Lab9 - Floyd
Lab10 - Deikstra
Lab11 - Kraskal
Lab12 - Yen
Lab13 - Seti

